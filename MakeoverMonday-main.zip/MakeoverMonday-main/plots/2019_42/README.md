### Week 42/2019 🏊🚴🏃 Ironman World Championship
![./plots/2019_42/2019_42_ironman.png](https://raw.githubusercontent.com/Z3tt/MakeOverMonday/master/plots/2019_42/2019_42_ironman.png)

**Alternate version:**  
![./plots/2019_42/2019_42_ironman_alt.png](https://raw.githubusercontent.com/Z3tt/MakeOverMonday/master/plots/2019_42/2019_42_ironman_alt.png)
