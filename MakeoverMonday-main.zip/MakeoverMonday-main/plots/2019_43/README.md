### Week 43/2019 ⁠😟 Deaths by Suicide and Drug Poisoning
![./plots/2019_43/2019_43_suicide_deaths.png](https://raw.githubusercontent.com/Z3tt/MakeOverMonday/master/plots/2019_43/2019_43_suicide_deaths.png)
