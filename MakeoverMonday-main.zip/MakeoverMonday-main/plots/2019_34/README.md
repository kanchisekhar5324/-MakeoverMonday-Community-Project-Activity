### Week 34/2019 ⁠📱📴 Smart Phone Use
![./plots/2019_34/2019_34_phone-use.png](https://raw.githubusercontent.com/Z3tt/MakeOverMonday/master/plots/2019_34/2019_34_phone-use.png)
